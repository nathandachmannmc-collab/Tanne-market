# HugoSMP Market – GitHub Pages

Dies ist eine statische Website-Demo mit Marktübersicht, Suche, Sortierung und Spieler-Karten.

## Wichtig
- Die Itempreise, Angebotszahlen, Spielernamen und Statistiken sind **Beispieldaten**.
- Sie sind keine echten Live-Daten von HugoSMP.
- Für automatische Live-Daten braucht die Website eine offizielle/erlaubte API oder eine andere rechtmäßig nutzbare Datenquelle.
- Dieses Fan-Projekt ist nicht offiziell mit HugoSMP verbunden.

## Auf GitHub veröffentlichen
1. Melde dich bei https://github.com/ an.
2. Erstelle ein öffentliches Repository, zum Beispiel `hugosmp-market`.
3. Lade `index.html` in das Hauptverzeichnis (`main`) hoch.
4. Öffne **Settings → Pages**.
5. Bei **Build and deployment** wähle **Deploy from a branch**.
6. Wähle Branch `main`, Ordner `/(root)`, dann **Save**.
7. Warte kurz, bis GitHub die Website veröffentlicht hat. Die Adresse steht danach im Bereich Pages.

## Anpassen
Die Beispieldaten stehen im JavaScript-Teil von `index.html` in den Arrays `items` und `players`.
